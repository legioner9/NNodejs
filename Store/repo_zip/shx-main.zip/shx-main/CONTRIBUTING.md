# Contributing

## Releasing

On the latest clean `main`:

```
npm run release:major
npm run release:minor
npm run release:patch
```
