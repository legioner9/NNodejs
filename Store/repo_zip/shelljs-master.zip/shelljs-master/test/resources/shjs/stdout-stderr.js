console.log('stdout: OK!');
console.error('stderr: OK!');
