<!--
Before posting your issue, please check our FAQ:
    https://github.com/shelljs/shelljs/wiki/FAQ
-->
### Node version (or tell us if you're using electron or some other framework):

### ShellJS version (the most recent version/Github branch you see the bug on):

### Operating system:

### Description of the bug:

### Example ShellJS command to reproduce the error:

```javascript

```
