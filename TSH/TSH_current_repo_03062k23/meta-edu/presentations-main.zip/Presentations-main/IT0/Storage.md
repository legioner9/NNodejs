# Persistent storage (постійне сховище)

## Terminology

- File (файл)
- Directory (folder, папка, каталог, директорія)
- Directory tree (дерево каталогів)
- Root directory (коренева директорія)
