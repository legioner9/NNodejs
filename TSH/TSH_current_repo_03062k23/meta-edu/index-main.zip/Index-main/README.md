# Metaeducation Global Initiative

- English
- [Русский](Docs/The-Concept-RU.md)
- Українська
