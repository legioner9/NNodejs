## Metaeducation links

- Telegram channel: [t.me/metaedu](https://t.me/metaedu)
- Telegram group:
  [t.me/joinchat/znsE73dPWLQ5Nzky](https://t.me/joinchat/znsE73dPWLQ5Nzky)
- Coordinator: [Timur Shemsedinov](mailto:timur.shemsedinov@gmail.com)
