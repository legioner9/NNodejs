# Personal Knowledge Map

- [Українська](Roadmap/Root-UA.md)
- [Русский](Roadmap/Root-RU.md)
- [English](Roadmap/Root-EN.md)
