## Kiev

## Contacts

- [Timur Shemsedinov](https://github.com/tshemsedinov)
- [Mariana Obuhivska-Shemsedinova](https://github.com/mariana-shemsedinova)
- Telegram channel: [metaedu](https://t.me/metaedu), [chat](https://t.me/joinchat/znsE73dPWLQ5Nzky)
