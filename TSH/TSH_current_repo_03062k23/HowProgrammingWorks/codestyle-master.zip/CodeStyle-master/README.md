# Code Style and Conventions
| [English](README.md) | [Русский](README.ru.md) |

1. [JavaScript](JavaScript/README.md)
2. [Haskell](Haskell/README.md)
3. [Python](https://www.python.org/dev/peps/pep-0008/)
4. [C++](C++/README.md)
5. [Go](https://golang.org/doc/effective_go.html)
6. [Swift](Swift/README.md)
7. [Java](Java/README.md)
8. [Lisp](Lisp/README.md)
9. [C#](CSharp/README.md)
10. [F#](FSharp/README.md)
