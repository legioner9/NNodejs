## Recursion

[Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)

[![Рекурсия: косвенная и хвостовая, стек, выход](https://img.youtube.com/vi/W2skCjIgVKE/0.jpg)](https://www.youtube.com/watch?v=W2skCjIgVKE)
