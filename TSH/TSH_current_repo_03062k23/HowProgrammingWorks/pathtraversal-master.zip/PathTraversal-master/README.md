## Path Traversal Attack

[![Безопасность приложений Node.js Security](https://img.youtube.com/vi/Pdfo1G-gI6s/0.jpg)](https://www.youtube.com/watch?v=Pdfo1G-gI6s)
