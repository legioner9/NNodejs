# ChainOfResponsibility
Pattern: Chain of responsibility
