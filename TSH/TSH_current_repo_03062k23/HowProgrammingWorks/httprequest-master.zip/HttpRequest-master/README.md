## HTTP Request, XMLHttpRequest, fetch

[![HTTP запросы в бреузере и Node.js: XMLHttpRequest, fetch](https://img.youtube.com/vi/wMMki2FEYGY/0.jpg)](https://www.youtube.com/watch?v=wMMki2FEYGY)
