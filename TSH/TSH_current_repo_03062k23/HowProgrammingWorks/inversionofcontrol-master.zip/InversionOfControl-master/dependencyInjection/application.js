'use strict';

const application = {};
module.exports = application;

application.main = () => {
  console.log('Application entry point');
};
