# GRASP: Creator principle
