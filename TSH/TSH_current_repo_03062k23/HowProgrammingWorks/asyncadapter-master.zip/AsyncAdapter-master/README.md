# Contract Adapters for Asynchronous Programming
[![Асинхронные адаптеры: promisify, callbackify, asyncify...](https://img.youtube.com/vi/76k6_YkYRmU/0.jpg)](https://www.youtube.com/watch?v=76k6_YkYRmU)
