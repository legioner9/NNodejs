# Metaprogramming

## Multi-paradigm approach in the Software Engineering

[Index EN](content/en/Index.md) | [Оглавление RU](content/ru/Index.md) | [Зміст UK](content/uk/Index.md) | [Obsah CZ](content/cz/Index.md)

To build pdf file run:

```
npm i
npm run build
```
