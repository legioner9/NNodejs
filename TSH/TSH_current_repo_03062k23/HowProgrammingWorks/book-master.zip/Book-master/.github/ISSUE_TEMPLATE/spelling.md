---
name: Spelling
about: Create a report to help us improve
title: ''
labels: spelling
assignees: ''
---

**Describe the problem** How it was and how you think it should be.

**Add link** Please add a URL to the file, certain place in this books or even to git blame (like this: https://github.com/HowProgrammingWorks/Book/blame/f47928a14c21d5ac2e2d218d10d10f330972929e/content/Abstract.en.md#L12-L17).

**Screenshots** If applicable, add screenshots to help explain an issue.
