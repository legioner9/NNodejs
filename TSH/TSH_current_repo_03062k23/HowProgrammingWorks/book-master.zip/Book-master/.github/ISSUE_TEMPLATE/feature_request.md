---
name: Feature request
about: Suggest an idea for this book
title: ''
labels: feature
assignees: ''
---

**Please describe your proposal.** A clear and concise description of what you want to see in this book.

**Describe alternatives you've considered** A clear and concise description of any alternative ideas you've considered.

**Add references** If you have references to other books, articles, videos, or even posts somewhere please add URLs here.
