## 1.5. Dekompozice a separace odpovědnosti

No translation
