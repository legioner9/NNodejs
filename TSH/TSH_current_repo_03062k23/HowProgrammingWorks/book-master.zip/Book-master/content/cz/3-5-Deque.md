## 3.5. Zásobník, fronta, deque

No translation
