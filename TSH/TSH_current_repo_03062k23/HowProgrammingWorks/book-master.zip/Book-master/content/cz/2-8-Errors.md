## 2.8. Výjimky a řešení chyb

No translation
