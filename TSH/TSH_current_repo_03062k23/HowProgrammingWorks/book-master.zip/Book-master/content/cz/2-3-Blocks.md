## 2.3. Operátor a výraz, blok kódu, funkce, smyčka, podmínka

No translation
