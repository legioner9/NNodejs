## 3.8. Odhad výpočetní složitosti

No translation
