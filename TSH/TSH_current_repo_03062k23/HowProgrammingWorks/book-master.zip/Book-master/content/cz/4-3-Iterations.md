## 4.3. Iterace: rekurze, iterátory a generátory

No translation
