## 2.7. Uzávěry, funkce zpětného volání, zabalení a události

No translation
