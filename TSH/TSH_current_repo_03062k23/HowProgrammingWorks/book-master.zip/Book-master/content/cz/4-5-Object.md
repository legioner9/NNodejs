## 4.5. Objekt, prototyp a třída

No translation
