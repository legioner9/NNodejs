## 2.2. Datové typy, skalární, referenční a strukturované typy

No translation
