## 3.3. Pole, seznam, sada, n-tice

No translation
