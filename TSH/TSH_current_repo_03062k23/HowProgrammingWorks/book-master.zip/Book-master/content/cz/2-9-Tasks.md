## 2.9. Úkoly

No translation
