## 3.1. Stavové a bezstavové přístupy (stateful and stateless)

No translation
