## 4.1. Co je technologický stack

No translation
