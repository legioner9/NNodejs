## 4.4. Stavební bloky aplikací: soubory, moduly, komponenty

No translation
