## 2.4. Kontexty a lexikální rozsah

No translation
