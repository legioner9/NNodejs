## 4.6. Částečná aplikace a curryfikace, skládání funkcí

No translation
