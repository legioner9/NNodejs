## 2.5. Procedurální paradigma, volání, zásobník a halda

No translation
