## 4.7. Řetězení pro metody a funkce (chaining)

No translation
