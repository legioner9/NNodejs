## 4.8. Mixiny (mixins)

No translation
