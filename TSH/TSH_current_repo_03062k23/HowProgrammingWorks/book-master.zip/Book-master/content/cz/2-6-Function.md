## 2.6. Funkce vyššího řádu, čistá funkce, vedlejší účinky

No translation
