## 2.1. Hodnota, identifikátor, proměnná a konstanta, literál, přiřazení

No translation
