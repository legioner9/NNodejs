({
  title: 'Metaprogramování',
  subtitle: 'Multiparadigmatický přístup v\nsoftwarovém inženýrství',
  copyright: '© Timur Shemsedinov, Společenství Metarhia',
  location: 'Kyjev, 2015 — 2022',
});
