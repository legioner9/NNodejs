## Odkazy

- Autor: https://github.com/tshemsedinov
- Telegram: https://t.me/HowProgrammingWorks
- Cvičení: https://github.com/HowProgrammingWorks/Index/blob/master/Exercises.ru.md
- Glosář: https://github.com/HowProgrammingWorks/Dictionary/blob/master/Fundamentals.ru.md
