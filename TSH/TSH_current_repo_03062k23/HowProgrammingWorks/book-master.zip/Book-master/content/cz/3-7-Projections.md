## 3.7. Projekce a zobrazení datových

No translation
