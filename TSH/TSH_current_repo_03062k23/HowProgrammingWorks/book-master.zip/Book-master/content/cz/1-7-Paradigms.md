## 1.7. Přehled programovacích paradigmat

No translation
