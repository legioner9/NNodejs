## 3.4. Slovník, hashovací tabulka a asociativní pole

No translation
