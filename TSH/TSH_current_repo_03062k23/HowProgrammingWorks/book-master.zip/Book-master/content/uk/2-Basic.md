## 2. Базові концепти

No translation

```js
// Single-line comment
```

```js
/*
  Multi-line
  comments
*/
```

```py
# Single-line comment
```

```py
"""
  Multi-line
  comments
"""
```

```sql
select name from PERSON -- comments in sql
```

```html
<!-- commented block in xml and html -->
```

```
; Single-line comment in Assembler and LISP
```
