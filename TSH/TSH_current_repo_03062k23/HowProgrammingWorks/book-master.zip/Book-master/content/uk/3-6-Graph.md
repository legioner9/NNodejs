## 3.6. Дерева та графи

No translation
