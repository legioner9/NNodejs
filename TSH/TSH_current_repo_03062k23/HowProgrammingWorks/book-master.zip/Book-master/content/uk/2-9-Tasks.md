## 2.9. Завдання

No translation
