## 4.8. Домішки (mixins)

No translation
