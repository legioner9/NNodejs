## 3.5. Стек, черга, дек

No translation
