## Посилання

- Автор: https://github.com/tshemsedinov
- Telegram: https://t.me/HowProgrammingWorks
- Завдання: https://github.com/HowProgrammingWorks/Index/blob/master/Exercises.ru.md
- Словник: https://github.com/HowProgrammingWorks/Dictionary/blob/master/Fundamentals.ru.md
