## 4.5. Об'єкт, прототип та клас

No translation
