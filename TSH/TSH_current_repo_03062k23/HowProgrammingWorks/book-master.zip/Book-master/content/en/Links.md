## Links

- Author: https://github.com/tshemsedinov
- Telegram: https://t.me/HowProgrammingWorks
- Exercises: https://github.com/HowProgrammingWorks/Index/blob/master/Exercises.ru.md
- Glossary: https://github.com/HowProgrammingWorks/Dictionary/blob/master/Fundamentals.ru.md
