## 1.5. Decomposition and separation of concerns

No translation
