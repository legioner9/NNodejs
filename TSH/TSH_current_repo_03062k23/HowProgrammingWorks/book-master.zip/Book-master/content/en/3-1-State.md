## 3.1. Stateful and stateless approach

No translation
