## 4.9. Dependencies and libraries

No translation
