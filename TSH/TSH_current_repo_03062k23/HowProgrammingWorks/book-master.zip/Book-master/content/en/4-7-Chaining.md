## 4.7. Chaining for methods and functions

No translation
