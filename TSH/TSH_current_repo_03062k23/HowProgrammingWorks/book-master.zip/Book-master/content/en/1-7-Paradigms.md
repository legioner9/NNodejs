## 1.7. Programming paradigms overview

No translation
