## 4.6. Partial application and currying, pipe and compose

No translation
