# 4. Extended concepts

No translation
