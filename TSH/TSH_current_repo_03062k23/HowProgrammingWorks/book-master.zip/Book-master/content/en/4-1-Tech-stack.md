## 4.1. What is a technology stack

No translation
