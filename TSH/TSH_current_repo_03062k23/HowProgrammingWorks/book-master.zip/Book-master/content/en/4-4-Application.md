## 4.4. Application building blocks: files, modules, components

No translation
