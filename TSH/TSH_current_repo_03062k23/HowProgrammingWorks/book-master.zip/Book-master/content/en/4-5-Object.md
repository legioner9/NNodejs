## 4.5. Object, prototype and class

No translation
