## 3.8. Computational complexity estimation

No translation
