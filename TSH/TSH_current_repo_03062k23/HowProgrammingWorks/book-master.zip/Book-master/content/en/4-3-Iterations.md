## 4.3. Iterations: recursion, iterators, and generators

No translation
