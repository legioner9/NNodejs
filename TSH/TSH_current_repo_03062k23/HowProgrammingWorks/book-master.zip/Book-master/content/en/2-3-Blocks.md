## 2.3. Operator and expression, code block, function, loop, condition

```js
(len - 1) * f(x, INTERVAL);
```

```js
const MAX_VALUE = 10;

console.log('Begin');
for (let i = 0; i < MAX_VALUE; i++) {
  console.dir({ i, date: new Date() });
}
console.log('The end');
```
