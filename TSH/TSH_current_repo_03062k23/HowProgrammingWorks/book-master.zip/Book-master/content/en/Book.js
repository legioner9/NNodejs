({
  title: 'Metaprogramming',
  subtitle: 'Multi-paradigm approach in the Software Engineering',
  copyright: '© Timur Shemsedinov, Metarhia community',
  location: 'Kiev, 2015 — 2022',
});
