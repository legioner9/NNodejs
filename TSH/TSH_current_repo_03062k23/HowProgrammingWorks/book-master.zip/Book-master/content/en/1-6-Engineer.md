## 1.6. Software engineer speciality overview

No translation
