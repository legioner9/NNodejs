# 3. Application state, data structures and collections

No translation
