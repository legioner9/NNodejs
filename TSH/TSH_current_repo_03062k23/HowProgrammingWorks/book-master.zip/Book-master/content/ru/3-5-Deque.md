## 3.5. Стек, очередь, дэк

No translation
