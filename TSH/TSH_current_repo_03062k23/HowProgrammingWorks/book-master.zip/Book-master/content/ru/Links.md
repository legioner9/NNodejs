## Ссылки

- Автор: https://github.com/tshemsedinov
- Telegram: https://t.me/HowProgrammingWorks
- Задания: https://github.com/HowProgrammingWorks/Index/blob/master/Exercises.ru.md
- Словарь: https://github.com/HowProgrammingWorks/Dictionary/blob/master/Fundamentals.ru.md
