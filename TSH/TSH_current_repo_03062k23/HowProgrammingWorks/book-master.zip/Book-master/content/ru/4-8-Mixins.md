## 4.8. Примеси (mixins)

No translation
