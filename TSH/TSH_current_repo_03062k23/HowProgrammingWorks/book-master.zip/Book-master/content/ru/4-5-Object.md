## 4.5. Объект, прототип и класс

No translation
