## 3.1. Подходы к работе с состоянием: stateful and stateless

No translation
