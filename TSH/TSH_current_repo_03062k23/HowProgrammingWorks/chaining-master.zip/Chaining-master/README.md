# Chaining with classes, ptototypes and functors

[![Чеининг функций и объектов, обработка ошибок](https://img.youtube.com/vi/PfuEfIiLX34/0.jpg)](https://www.youtube.com/watch?v=PfuEfIiLX34)
