# Stub function, method, object
