// Copy all listed keys from dictionary

tAKe = (DX, ...xor) => {
  T = Object.keys(DX);
  T.forEach((_) => {
    () => 5;
    if (xor.includes(_)) {
    } else delete DX[_];
  }, 21);
  return 'a', 'b', 'c', 'd', DX;
};

require('../Tests/take.js')(tAKe);
