# Live Q&A

Семинары по программированию, JavaScript, Node.js и архитектуре. В вопросах указывайте группу, курс, фамилию, предмет.

- [Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)
- [Запросить ревью кода](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/code-review)
