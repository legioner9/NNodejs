#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification 4-array
