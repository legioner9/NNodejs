#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification a-tick
