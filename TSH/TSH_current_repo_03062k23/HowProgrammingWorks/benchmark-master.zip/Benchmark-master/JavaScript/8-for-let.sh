#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification 8-for-let
