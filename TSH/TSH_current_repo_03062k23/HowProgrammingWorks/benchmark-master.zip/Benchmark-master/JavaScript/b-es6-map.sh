#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification b-es6-map
