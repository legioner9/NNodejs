#!/bin/sh

node --allow-natives-syntax --nouse-idle-notification matchKnownFields1.js
node --allow-natives-syntax --nouse-idle-notification matchKnownFields2.js
node --allow-natives-syntax --nouse-idle-notification matchKnownFields3.js
node --allow-natives-syntax --nouse-idle-notification matchKnownFields4.js
