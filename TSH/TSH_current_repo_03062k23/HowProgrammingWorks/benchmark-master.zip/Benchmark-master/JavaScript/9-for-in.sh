#!/bin/sh
node --allow-natives-syntax --nouse-idle-notification 9-for-in
