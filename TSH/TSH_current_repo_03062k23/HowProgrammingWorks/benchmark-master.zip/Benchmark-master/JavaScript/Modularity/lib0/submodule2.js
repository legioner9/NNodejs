'use strict';

module.exports = {

  third(value) {
    return value;
  },

  fourth(value) {
    return value;
  }

};
