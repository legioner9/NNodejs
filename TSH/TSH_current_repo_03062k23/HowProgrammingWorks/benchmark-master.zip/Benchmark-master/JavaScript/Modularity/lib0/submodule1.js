'use strict';

module.exports = {

  first(value) {
    return value;
  },

  second(value) {
    return value;
  }

};
