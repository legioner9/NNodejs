'use strict';

const moduleName = {};
module.exports = moduleName;

moduleName.first = (value) => value;

moduleName.second = (value) => value;
