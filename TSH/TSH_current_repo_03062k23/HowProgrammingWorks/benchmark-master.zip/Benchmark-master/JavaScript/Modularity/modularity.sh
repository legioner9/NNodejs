#!/bin/sh

node --allow-natives-syntax modularity.js
