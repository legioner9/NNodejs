# Atomic transaction container for struct or object
[![Слой доступа к данным, курсор, транзакция](https://img.youtube.com/vi/CRcSWtWVvrA/0.jpg)](https://www.youtube.com/watch?v=CRcSWtWVvrA)
