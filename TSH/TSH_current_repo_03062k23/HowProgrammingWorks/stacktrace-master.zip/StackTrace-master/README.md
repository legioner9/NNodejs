## Stack Trace problem in Node.js

[![Проблема асинхронного стектрейса в JavaScript](https://img.youtube.com/vi/pfiHTx3j87Y/0.jpg)](https://www.youtube.com/watch?v=pfiHTx3j87Y)
