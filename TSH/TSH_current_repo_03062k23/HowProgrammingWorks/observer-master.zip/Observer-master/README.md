## Pattern Observer

[![Паттерн Наблюдатель (Observer + Observable)](https://img.youtube.com/vi/_bFXuLcXoXg/0.jpg)](https://www.youtube.com/watch?v=_bFXuLcXoXg)
