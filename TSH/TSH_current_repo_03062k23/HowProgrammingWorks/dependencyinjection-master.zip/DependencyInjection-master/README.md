# Resolving dependencies with dependency injection

[![Инверсия управления и внедрение зависимостей](https://img.youtube.com/vi/Fz86Fdjz-LM/0.jpg)](https://www.youtube.com/watch?v=Fz86Fdjz-LM)
