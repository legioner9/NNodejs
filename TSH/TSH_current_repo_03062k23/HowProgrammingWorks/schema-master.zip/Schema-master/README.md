# Schema
Schema for APIs, Data structures and Databases
