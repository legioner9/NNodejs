## Pattern Command

[![Паттерн Команда (Command) действие и параметры как объект](https://img.youtube.com/vi/vER0vYL4hM4/0.jpg)](https://www.youtube.com/watch?v=vER0vYL4hM4)
