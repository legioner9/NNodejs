'use strict';

class Logger {
  warn() {}
  error() {}
  info() {}
}

module.exports = { Logger };
