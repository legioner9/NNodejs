# Network Socket Endpoint Interface

[![Клиент-сервер на Node.js TCP и UDP, DNS ](https://img.youtube.com/vi/bHn-wTlTTR0/0.jpg)](https://www.youtube.com/watch?v=bHn-wTlTTR0)
