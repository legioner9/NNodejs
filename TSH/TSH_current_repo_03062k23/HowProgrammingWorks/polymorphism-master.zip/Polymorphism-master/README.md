# Polymorphism

[Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)

[![ООП: наследование и полиморфизм](https://img.youtube.com/vi/8OuzIAuMfjw/0.jpg)](https://youtu.be/8OuzIAuMfjw)
