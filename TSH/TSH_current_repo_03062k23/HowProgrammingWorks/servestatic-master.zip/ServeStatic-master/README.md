# Serve static content with HTTP

[![Отдача статики в Node.js](https://img.youtube.com/vi/n_AdKIzbpBc/0.jpg)](https://youtu.be/n_AdKIzbpBc)
