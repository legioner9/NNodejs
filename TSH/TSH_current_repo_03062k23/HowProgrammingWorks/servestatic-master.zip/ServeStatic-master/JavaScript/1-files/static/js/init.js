'use strict';

console.log('JavaScript loaded');
