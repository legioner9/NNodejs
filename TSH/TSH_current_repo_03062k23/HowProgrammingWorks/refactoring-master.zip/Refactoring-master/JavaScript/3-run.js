'use strict';

const { shortenStack } = require('./1-module.js');
const { tests } = require('./2-tests.js');
tests(shortenStack);
