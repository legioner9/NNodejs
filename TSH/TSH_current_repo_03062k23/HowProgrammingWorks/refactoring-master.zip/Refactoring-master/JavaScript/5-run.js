'use strict';

const { shortenStack } = require('./4-refactored.js');
const { tests } = require('./2-tests.js');
tests(shortenStack);
