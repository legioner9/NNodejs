# GRASP: Pure Fabrication

[Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)

[![Чистая выдумка / Pure Fabrication](https://img.youtube.com/vi/CV577a0RHBM/0.jpg)](https://www.youtube.com/watch?v=CV577a0RHBM)
