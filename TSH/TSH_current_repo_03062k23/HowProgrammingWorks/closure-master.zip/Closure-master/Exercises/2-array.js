'use strict';

const array = () => null;

module.exports = { array };
