## Чат на Websocket
[![WebSocket сервер на Node.js (электронные таблицы и чат)](https://img.youtube.com/vi/Sf7ln3n16ws/0.jpg)](https://www.youtube.com/watch?v=Sf7ln3n16ws)

* `server.js` - серверная часть, слушает TCP порт 8000 (ждет подключений)
* Клиентская часть `index.html`: открыть в браузере через `127.0.0.1:8000`

## Задания

## Дополнительные задания
