# Metarhia application example

Please see this: https://github.com/metarhia/Example
or use Node.js Starter Kit for pure Node.js application with compatible
structure: https://github.com/HowProgrammingWorks/NodejsStarterKit

