# String is a Sequence of Characters and Manipulation Methods

[![Работа со строками, шаблонами и юникодом](https://img.youtube.com/vi/GcopcHQkA8M/0.jpg)](https://www.youtube.com/watch?v=GcopcHQkA8M)
