'use strict';

const store = (x) => null;

module.exports = { store };
