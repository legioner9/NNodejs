'use strict';

module.exports = async () => [
  'Timur Shemsedinov',
  'tshemsedinov@github',
  'timur.shemsedinov@gmail.com',
  'tshemsedinov@facebook',
  'marcusaurelius@habrahabr',
];
