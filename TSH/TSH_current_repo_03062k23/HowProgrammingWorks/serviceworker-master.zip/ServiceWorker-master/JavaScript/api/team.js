'use strict';

module.exports = async () => [
  'Metarhia core team:',
  '@tshemsedinov @aqrln @belochub @nechaido @GYFK @lidaamber',
  '@lundibundi @GreatAndPowerfulKing @grimelion @DzyubSpirit',
  '@RayGron @alinkedd @j-martyn @johnbizokk @bugagashenkj',
  '@Kowalski0805 @dimanadko @kuvichkamaksim @mille-nium',
  '@o-rumiantsev @Tariod',
];
