'use strict';

module.exports = async () => [
  'Links:',
  '• Open Source code https://github.com/metarhia',
  '• Educational code Examples https://github.com/HowProgrammingWorks',
  '',
  'Meetup Groups:',
  '• https://www.meetup.com/HowProgrammingWorks',
  '• https://www.meetup.com/NodeUA',
  '• https://www.meetup.com/KievNodeJS',
  '',
  'Telegram Channels:',
  '• https://t.me/HowProgrammingWorks',
  '• https://t.me/metarhia',
  '',
  'Telegram Groups:',
  '• https://t.me/MetarhiaHPW',
  '• https://t.me/nodeua',
];
