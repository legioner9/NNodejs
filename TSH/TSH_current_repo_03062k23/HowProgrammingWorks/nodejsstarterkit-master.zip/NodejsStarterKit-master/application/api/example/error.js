async () => new Error('Hello!', 54321);
