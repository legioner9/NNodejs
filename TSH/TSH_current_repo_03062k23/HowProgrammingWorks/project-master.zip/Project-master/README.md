# Example Node.js project

[Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)

[![Модули, слои, структура проекта, песочницы](https://img.youtube.com/vi/O7A9chb573E/0.jpg)](https://www.youtube.com/watch?v=O7A9chb573E)
