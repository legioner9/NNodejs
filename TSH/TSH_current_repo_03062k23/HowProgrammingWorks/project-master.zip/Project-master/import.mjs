import { field, func } from './export.mjs';

console.dir({ require });

console.log({ field, func });
