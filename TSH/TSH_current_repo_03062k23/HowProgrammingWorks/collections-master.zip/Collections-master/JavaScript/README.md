# Collections in JavaScript

- Array - https://github.com/HowProgrammingWorks/DataStructures
- Object - https://github.com/HowProgrammingWorks/DataTypes
- Map, WeakMap - https://github.com/HowProgrammingWorks/Map
- Set, WeakSet - https://github.com/HowProgrammingWorks/Set
- List - https://github.com/HowProgrammingWorks/LinkedList
- Stack, Queue, Dequeue - https://github.com/HowProgrammingWorks/Dequeue
