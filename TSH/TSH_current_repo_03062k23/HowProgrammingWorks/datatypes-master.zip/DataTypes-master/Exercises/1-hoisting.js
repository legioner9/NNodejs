'use strict';

const fn = null;

module.exports = { fn };
