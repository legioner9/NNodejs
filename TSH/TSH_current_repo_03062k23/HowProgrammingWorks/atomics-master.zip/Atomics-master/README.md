## Atomics Operations API

[![Atomics, SharedArrayBuffer, worker_threads в Node.js](https://img.youtube.com/vi/zLm8pnbxSII/0.jpg)](https://www.youtube.com/watch?v=zLm8pnbxSII)

Next examples:
* [BinarySemaphore and CountingSemaprore](https://github.com/HowProgrammingWorks/Semaphore)
* [Preventing race conditions with Mutual Exclusion](https://github.com/HowProgrammingWorks/Mutex)
