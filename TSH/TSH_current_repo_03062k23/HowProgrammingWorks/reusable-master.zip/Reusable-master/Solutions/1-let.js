'use strict';

let name = 'Marcus';

module.exports = { name };
