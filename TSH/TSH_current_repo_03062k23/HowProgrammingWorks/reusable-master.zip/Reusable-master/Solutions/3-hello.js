'use strict';

const hello = (name) => {
  console.log(`Hello, ${name}!`);
};

module.exports = { hello };
