'use strict';

const phonebook = null;

const findPhoneByName = null;

module.exports = { phonebook, findPhoneByName };
