'use strict';

const year = undefined;

module.exports = { year };
