'use strict';

const square = null;

const cube = null;

const average = null;

const calculate = null;

module.exports = { square, cube, average, calculate };
