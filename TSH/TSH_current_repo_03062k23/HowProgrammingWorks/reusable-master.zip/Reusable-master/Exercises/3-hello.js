'use strict';

const hello = null;

module.exports = { hello };
