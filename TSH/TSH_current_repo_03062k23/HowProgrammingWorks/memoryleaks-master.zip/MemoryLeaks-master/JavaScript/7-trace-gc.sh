#!/bin/sh
node --trace_gc 7-trace-gc
