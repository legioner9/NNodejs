#!/bin/sh
node --expose-gc --nouse-idle-notification 6-gc
