#!/bin/sh
node --inspect 8-inspect
