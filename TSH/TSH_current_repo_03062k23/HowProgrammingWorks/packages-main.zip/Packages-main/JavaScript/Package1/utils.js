'use strict';

module.exports = { add: (a, b) => a + b };
