'use strict';

module.exports = { hint: 'Package1: package.js' };
