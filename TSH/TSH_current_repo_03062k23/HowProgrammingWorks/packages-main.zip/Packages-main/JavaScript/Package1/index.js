'use strict';

module.exports = { hint: 'Package1: index.js' };
