## Reflection allows programs to introspect and modify its structure and behavior at runtime

[![Интроспекция и рефлексия в JavaScript](https://img.youtube.com/vi/yvW1PjUVeM0/0.jpg)](https://www.youtube.com/watch?v=yvW1PjUVeM0)
