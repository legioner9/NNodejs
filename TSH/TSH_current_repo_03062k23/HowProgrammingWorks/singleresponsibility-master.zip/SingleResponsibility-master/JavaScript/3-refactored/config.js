'use strict';

module.exports = {
  format: 'json'
};
