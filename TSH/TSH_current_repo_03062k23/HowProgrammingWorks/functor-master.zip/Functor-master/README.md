# Mappable objects

[![Функциональные объекты, функторы и монады](https://img.youtube.com/vi/3Z7f0Gi8pxw/0.jpg)](https://www.youtube.com/watch?v=3Z7f0Gi8pxw)
