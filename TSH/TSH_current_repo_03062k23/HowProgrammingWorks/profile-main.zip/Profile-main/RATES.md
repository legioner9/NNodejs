# Rates

- Development
- Consulting
- Code review
- Talks
- Educational programs
- etc.
