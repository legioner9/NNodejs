<code>🎓 Student: KPI / IM-11</code>
<code>⚪ Community: Metarhia</code>
<code>👷 Speciality: Software engineer / Backend</code><br>
<code>💡 [Skills](SKILLS.md)</code>
<code>🧻 [Projects](PROJECTS.md)</code>
<code>📢 [Public talks: 0](TALKS.md)</code>
<code>👀 [Open-source contribution](CONTRIBUTION.md)</code><br>
<code>🧑‍💻 Languages: JavaScript, C++</code>
<code>📦 Tech stack: node.js</code>
<code>🪙 [Rates](RATES.md)</code><br>
<code>💬 telegram: [@your-nikname](https://telegram.me/your-nikname)</code>
<code>📫 [your-email](mailto:your-email)</code>
