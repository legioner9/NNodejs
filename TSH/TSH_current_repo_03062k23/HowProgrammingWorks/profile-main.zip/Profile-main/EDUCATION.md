# Education

- Kiev Polytechnic Institute
- Metarhia free educational program
