'use strict';

const inc = (num) => {
  num.n += 1;
};

module.exports = { inc };
