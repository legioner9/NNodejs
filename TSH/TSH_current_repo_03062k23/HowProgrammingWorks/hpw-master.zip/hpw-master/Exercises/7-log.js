'use strict';

const { log: ln } = Math;
const log = (base, n) => ln(n) / ln(base);

module.exports = { ln, log };
