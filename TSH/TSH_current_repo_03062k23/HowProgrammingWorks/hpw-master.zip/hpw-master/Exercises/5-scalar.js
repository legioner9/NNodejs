'use strict';

const name = 'Marcus Aurelius';

module.exports = { name };
