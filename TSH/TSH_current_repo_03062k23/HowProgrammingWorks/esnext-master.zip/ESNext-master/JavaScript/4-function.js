'use strict';

const fn = (a, b) => {
  const c = a + b; // hello there
  return c;
};

console.log(fn.toString());
