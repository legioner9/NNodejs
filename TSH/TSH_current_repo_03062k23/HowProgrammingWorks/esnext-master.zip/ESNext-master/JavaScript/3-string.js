'use strict';

// String.prototype.padStart(targetLength [, padString])
console.dir('hello'.padStart(20, '.'));

// String.prototype.padEnd(targetLength [, padString])
console.dir('hello'.padEnd(20, '.'));

// String.prototype.trimStart()
console.dir('   hello   '.trimStart());

// String.prototype.trimEnd()
console.dir('   hello   '.trimEnd());
