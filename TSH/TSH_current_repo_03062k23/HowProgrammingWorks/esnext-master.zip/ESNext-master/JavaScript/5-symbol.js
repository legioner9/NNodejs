'use strict';

const sym = Symbol('description');

console.log(sym);
console.log(sym.description);
