# ES.Next, ECMAScript 2020, ES2019

[![Новое в JavaScript: ES.Next, ECMAScript 2020, ES11, ES10, ES9, ES8, ES7, ES6, ES2020, ES2019](https://img.youtube.com/vi/fUjHLj8bq_Y/0.jpg)](https://www.youtube.com/watch?v=fUjHLj8bq_Y)
