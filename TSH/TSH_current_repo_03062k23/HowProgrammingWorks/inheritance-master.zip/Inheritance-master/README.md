# Inheritance in Different Paradigms

[![ООП: наследование и полиморфизм](https://img.youtube.com/vi/8OuzIAuMfjw/0.jpg)](https://youtu.be/8OuzIAuMfjw)
