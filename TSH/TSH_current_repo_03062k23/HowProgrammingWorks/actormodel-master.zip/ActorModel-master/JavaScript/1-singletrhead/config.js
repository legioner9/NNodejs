'use strict';

module.exports = {
  user: 'account-name@gmail.com',
  pass: 'your-password',
};
