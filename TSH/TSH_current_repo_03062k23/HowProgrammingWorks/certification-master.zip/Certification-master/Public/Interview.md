# Public interview index

1. 🎧 [Metarhia Public interview #1: iOS, Swift, Async code, HTTPS, Sockets, DDD, Patterns](https://youtu.be/pURUQ_e4i1o)
    - Dmitriy Dmitriyev https://github.com/dirayser
2. 🎧 [Public interview #2: Java, Node.js, DDD, ООП, паттерны, парадигмы, безопасность](https://youtu.be/sVWElH2Fx_c)
    - Maxim Perevalov https://github.com/a-mountain
3. 🎧 [Public interview #3: TypeScript, schema, state, MobX, fp, patterns](https://youtu.be/TakH5i5VRGk)
    - Alex Chorny
4. 🎧 [Public interview #4: JavaScript, Python, асинхронное программирование, React, Node.js, паттерны](https://youtu.be/9sZCii1DHOM)
    - Yevhenii Petrenko https://github.com/vekaev
5. 🎧 [Public interview #5: net, c#, angular, асинхронность, patterns, db, orm, api, garbage collection](https://youtu.be/jtW8bHPL6_4)
    - Alexander Tkachenko https://github.com/AlexanderPixel
6. 🎧 [Public interview #6: JavaScript, collection, complexity, async, node.js, patterns](https://youtu.be/_g9bjgicmDI)
    - Alexey Bodnarchuk https://github.com/Alexe1900
