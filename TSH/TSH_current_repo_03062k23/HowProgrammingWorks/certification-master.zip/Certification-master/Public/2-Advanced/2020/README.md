# Advanced Knowledge in Software Engineer

* Александр Пальоха https://github.com/PalokhaO
* Денис Пархоменко https://github.com/hunter04d
