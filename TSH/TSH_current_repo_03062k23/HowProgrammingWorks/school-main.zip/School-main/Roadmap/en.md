## Modern school program

Attention: the knowledge map is not age-specific and should be converted into lesson topics adapted in each certain case.

- [Digital literacy](Literacy-en.md)
- [Programming (fundamentals for all)](Programming-ru.md)
- [Web development (optional)](Web-ru.md)
- [Frontend (optional)](Frontend-ru.md)
- [Software engineering (optional)](Software-ru.md)
