# Set
Set is a Collection of Distinct Values or Objects

[![Коллекции, множества, хештаблицы](https://img.youtube.com/vi/hN0wsq5LNOc/0.jpg)](https://www.youtube.com/watch?v=hN0wsq5LNOc)
