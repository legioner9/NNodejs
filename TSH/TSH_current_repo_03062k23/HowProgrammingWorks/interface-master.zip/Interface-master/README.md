# Interface
Structure defining class external members names and types
