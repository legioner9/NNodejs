// Usage
const person1 = { name: 'Zedong', surname: 'Mao' };
const person2 = { surname: 'Mao' };
console.dir({ person1, person2 });
