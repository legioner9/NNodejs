'use strict';

// Antipattern: Not Invented Here
//
// Advantages
// - No dependencies - no problems (remember left-pad)
// - Security
//
// Disadvantages
// - Waste of time
// - Solution quality
