'use strict';

module.exports = {
  name: {
    length: 17
  },
  fileName: '2-hard-code.js',
};
