# Proxy

[Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)

[![Использование Proxy и Symbol](https://img.youtube.com/vi/UjZjSDyi9AM/0.jpg)](https://www.youtube.com/watch?v=UjZjSDyi9AM)
