import { Entity, fn, collection } from './8-export.mjs';
import m1 from './1-export.js';

console.log({ Entity, fn, collection });
console.log(m1);
