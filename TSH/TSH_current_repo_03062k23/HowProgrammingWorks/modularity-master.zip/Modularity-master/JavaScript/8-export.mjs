class Entity {}

const fn = x => x;

const collection = new Map();

// module.exports = { Entity, fn, collection };
export { Entity, fn, collection };
