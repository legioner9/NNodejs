import m from 'node:module';
console.log(m);
console.log();
console.log(module);
