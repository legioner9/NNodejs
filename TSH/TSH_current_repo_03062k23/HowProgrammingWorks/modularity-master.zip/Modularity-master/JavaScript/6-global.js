'use strict';

require('./5-singleton.js');

const { collection } = require('./1-export.js');
console.log(collection);
