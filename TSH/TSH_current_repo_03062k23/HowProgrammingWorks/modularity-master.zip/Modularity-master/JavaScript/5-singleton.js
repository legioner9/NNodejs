'use strict';

const { collection } = require('./1-export.js');
collection.set('key1', 'value1');
