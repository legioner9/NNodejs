'use strict';

const m = require('node:module');
console.log(m);
console.log();
console.log(module);
