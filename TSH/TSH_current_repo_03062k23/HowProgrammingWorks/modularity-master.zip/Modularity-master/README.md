# Modularity and Dependency

[![Node.js модули: ECMA, Common.js, Module API](https://img.youtube.com/vi/CJr2vS3hjMU/0.jpg)](https://www.youtube.com/watch?v=CJr2vS3hjMU)
