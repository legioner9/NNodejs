# Exercises

## Refactor

1. See badServer.js and think about bad practices
2. See goodServer.js and compare to previous bad code
2. Rewrite badServer.js decomposing code to different layers

## Improve functionality
