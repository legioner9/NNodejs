## Lenses, fp getter &amp; setter

[![Линзы - функциональные аналоги геттера и сеттера в JavaScript](https://img.youtube.com/vi/IBF5gFU6G-o/0.jpg)](https://www.youtube.com/watch?v=IBF5gFU6G-o)
