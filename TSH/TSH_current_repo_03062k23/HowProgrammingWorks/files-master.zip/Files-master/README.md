# Files and file system

[![Работа с файлами, буферами и файловыми потоками](https://img.youtube.com/vi/eQGBS15vUac/0.jpg)](https://www.youtube.com/watch?v=eQGBS15vUac)
[![Наблюдение за файловой системой в Node.js](https://img.youtube.com/vi/29QINR9rruQ/0.jpg)](https://www.youtube.com/watch?v=29QINR9rruQ)
