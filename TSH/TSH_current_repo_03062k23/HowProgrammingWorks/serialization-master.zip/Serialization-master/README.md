# Translating data structures into syntactic structures or binary format

[![Сериализация и десериализация](https://img.youtube.com/vi/GtKPniOEzh8/0.jpg)](https://www.youtube.com/watch?v=GtKPniOEzh8)
