# Data structures projection

[Задать вопрос](https://github.com/HowProgrammingWorks/LiveQA/discussions/categories/q-a)

[![Проекции и отображения наборов данных](https://img.youtube.com/vi/lwJCq9inky8/0.jpg)](https://www.youtube.com/watch?v=lwJCq9inky8)
