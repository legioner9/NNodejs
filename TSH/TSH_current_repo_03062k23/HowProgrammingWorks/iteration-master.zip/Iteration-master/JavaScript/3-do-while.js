'use strict';

let i = 0;
do {
  console.log(i++);
} while (i < 10);
