declare namespace common {
  function hash(password: string): Promise<string>;
}
