({
  Entity: {},

  area: 'Area',
  from: 'Account',
  text: 'string',
});
