({
  name: 'messenger',
  description: 'Messenger database',
  version: 1,
  driver: 'pg',

  authors: [
    { name: 'Timur Shemsedinov', email: 'timur.shemsedinov@gmail.com' },
  ],
});
