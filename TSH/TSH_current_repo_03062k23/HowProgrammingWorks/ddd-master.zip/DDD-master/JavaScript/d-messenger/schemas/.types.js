({
  ip: { js: 'string', metadata: { pg: 'inet' } },
});
