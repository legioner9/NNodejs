# Command Line Interface and Console
[![Консоль и командная строка](https://img.youtube.com/vi/5aSZyKi5BmE/0.jpg)](https://www.youtube.com/watch?v=5aSZyKi5BmE)
