'use strict';

console.log('Level 1');
console.group();
console.log('Level 2');
console.group();
console.log('Level 3');
console.groupEnd();
console.log('Message 1');
console.groupEnd();
console.log('Message 2');
