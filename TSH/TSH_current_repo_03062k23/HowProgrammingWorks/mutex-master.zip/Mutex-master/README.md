## Mutex: Preventing race conditions with Mutual Exclusion

[![Семафоры и мьютексы в JavaScript и Node.js](https://img.youtube.com/vi/JNLrITevhRI/0.jpg)](https://www.youtube.com/watch?v=JNLrITevhRI)

[![Shared memory and multithreading in Node.js](https://image.slidesharecdn.com/timur-jsfest19-190406113647/95/shared-memory-and-multithreading-in-nodejs-timur-shemsedinov-jsfest19-1-638.jpg)](https://www.slideshare.net/tshemsedinov/shared-memory-and-multithreading-in-nodejs-timur-shemsedinov-jsfest19)
