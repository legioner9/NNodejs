# Расписание NodeUA на 2019-2020

- чт 05 сен: [Node.js в 2019 году](https://youtu.be/CUU49jjHloM)
- чт 12 сен: [Graceful Shutdown в Node.js](https://youtu.be/ZstnowFeCe0)
- чт 19 сен: [Отдача статики в Node.js](https://youtu.be/n_AdKIzbpBc)
- чт 26 сен: [Применение EventSourcing](https://youtu.be/kFNtKiK2SPs)
- чт 03 окт: [Progressive Web Applications PWA и ServiceWorkers](https://youtu.be/s7AIwZMTVPs)
- чт 10 отк: [JavaScript в браузере: Web API (часть 1)](https://youtu.be/6O8SBJsNeNw)
- чт 17 отк: [Принцип единственной ответственности и закон Конвея](https://youtu.be/o4bQywkBKOI)
- чт 31 отк: [Ассоциация, Агрегация и Композиция](https://youtu.be/tOIcBrzezK0)
- чт 07 ноя: [Принцип подстановки Барбары Лисков](https://youtu.be/RbhYxygxroc)
- чт 21 ноя: [Антипаттерны объектно-ориентированного программирования](https://youtu.be/9d5TG1VsLeU)
- чт 28 ноя: [Безопасность приложений Node.js](https://youtu.be/Pdfo1G-gI6s)
- чт 05 дек: [Serverless Clouds (FaaS) и изоляция контекстов запросов в Node.js](https://youtu.be/x-Rd6fPV6L8)
