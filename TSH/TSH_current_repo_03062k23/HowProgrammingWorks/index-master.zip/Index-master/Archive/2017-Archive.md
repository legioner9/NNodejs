## Семинары и доклады 2017

### Семинары весной 2017

- [Архив 2017 - Чудесный мир конвенций кода - Алексей Орленко](https://youtu.be/Igbs4BrIhKY)
- [Архив 2017 - О важности последовательного стиля кодирования - Денис Отришко](https://youtu.be/eRrJbyY-ipY)
- [Архив 2017 - Про технологический стек Metarhia - Тимур Шемсединов](https://youtu.be/x5-dl1vKa-8)
- [Архив 2017 - Процесс разработки - Алексей Орленко](https://youtu.be/FMFRl1xkhjU)
- [Архив 2017 - JSTP JavaScript Transfer Protocol - Алексей Орленко](https://youtu.be/So-y0TGSjtI)
- [Архив 2017 - MetaSync - Тимур Шемсединов](https://youtu.be/xNfOv9I1MDk)
- [Архив 2017 - GlobalStorage - Тимур Шемсединов](https://youtu.be/BMtDj5dP3e0)
- [Архив 2017 - Impress Application Server - Тимур Шемсединов](https://youtu.be/ymueF-9FDCs)
- [Архив 2017 - Масштабирование Node.js для высоких нагрузок - Тимур Шемсединов - JS Conference 2017](https://youtu.be/-yJWLaJ31NI)

### Выступление и разное

- [Асинхронное программирование на JS и Node.js](https://youtu.be/VdRhAXnfrd0)
- [Epic invitation to #OdessaJS2017](https://youtu.be/Ysnl6Ex1OZw)
- [Ваше положение таково, что понять вам его невозможно](https://youtu.be/fbhwG3KwmUY)
