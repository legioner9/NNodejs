# Семинары: основы программирования, JavaScript и другие языки

- [JavaScript семинар #1 по курсу HowProgrammingWorks](https://youtu.be/eYjf_WrYAqk)
- [JavaScript семинар #2 по курсу HowProgrammingWorks](https://youtu.be/05iTAT_t6cI)
- [JavaScript семинар #3 по курсу HowProgrammingWorks](https://youtu.be/CtwTMX6wZpY)
- [JavaScript семинар #8 по курсу HowProgrammingWorks](https://youtu.be/T7e9D4sAYWY)
- [💻 JavaScript семинар #10: рефакторинг и ревью кода](https://youtu.be/efb7sAOeMPQ)
- [💻 JavaScript семинар #11: рефакторинг и ревью кода](https://youtu.be/kLBR2dkebGk)
- [💻 JavaScript семинар #12: рефакторинг и ревью кода](https://youtu.be/s2gAKg9CtsI)
- [💻 Семинар #14: ревью проектов на JavaScript и Java](https://youtu.be/l-joOy1Y2SI)
- [💻 JavaScript семинар #15: ревью кода](https://youtu.be/XcFfpbkYxlg)
