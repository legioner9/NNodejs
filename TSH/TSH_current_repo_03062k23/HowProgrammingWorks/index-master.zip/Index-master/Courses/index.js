({
  intro: {
    title: 'Introduction to software engineering',
  },
  sef1: {
    title: 'Software engineering fundamentals: part 1',
  },
  sef2: {
    title: 'Software engineering fundamentals: part 2',
  },
  sef3: {
    title: 'Software engineering fundamentals: part 3',
  },
  pps1: {
    title: 'Asynchronous programming',
  },
  pps2: {
    title: 'Parallel programming',
  },
  pps3: {
    title: 'Distributed systems',
  },
  nts1: {
    title: 'Node.js technology stack: part1',
  },
  nts2: {
    title: 'Node.js technology stack: part2',
  },
  nts3: {
    title: 'Node.js technology stack: part3',
  },
  isa1: {
    title: 'Information system architecture: part1',
  },
  isa2: {
    title: 'Information system architecture: part2',
  },
});
