# Roadmap: варианты роадмапа для разных специальностей

## Общая схема

![Roadmap common)](https://user-images.githubusercontent.com/4405297/192536927-36a20aea-d19e-4a68-9087-fd9343027c76.png)

## Роадмап для Backend

![Roadmap Backend](https://user-images.githubusercontent.com/4405297/192537072-9ff87e51-52c2-4686-b401-5372e8a02814.png)

## Роадмап для Frontend

![Roadmap Frontend](https://user-images.githubusercontent.com/4405297/192537239-ce531a3c-b76a-4fc1-a598-a57099fbf794.png)

## Роадмап для специалиста по доменной логике и бизнес-анализу

![Roadmap Domain](https://user-images.githubusercontent.com/4405297/192537433-48228dfb-9c04-4e39-bb5c-8fead555e2ad.png)

## Роадмап для лоукодера

![Roadmap Lowcode](https://user-images.githubusercontent.com/4405297/192537488-52db0b54-964a-48ff-af84-c280a2130d36.png)
