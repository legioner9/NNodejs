# GRASP: принципы распределения ответственности

- [GRASP принципы с адаптацией для JavaScript и Node.js](https://youtu.be/ExauFjYV_lQ)
- [Принцип информационный эксперт / Information Expert](https://youtu.be/cCHL329_As0)
- [Зацепление и связность / Coupling and Cohesion](https://youtu.be/IGXdPOZ3Fyk)
- [Чистая выдумка / Pure Fabrication](https://youtu.be/CV577a0RHBM)
- [Пример декомпозиции класса](https://youtu.be/4AMVQ2-2DcM)
