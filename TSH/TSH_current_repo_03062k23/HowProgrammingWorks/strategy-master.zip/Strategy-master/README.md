## Strategy Pattern

[![Стратегия (Strategy) - выбор взаимозаменяемого поведения](https://img.youtube.com/vi/hO8VSVv0NqM/0.jpg)](https://www.youtube.com/watch?v=hO8VSVv0NqM)
