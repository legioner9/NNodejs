## Scaffolding for UI, API, Classes, etc.

[![Скаффолдинг для API, UI и данных](https://img.youtube.com/vi/lipkLQVqDd8/0.jpg)](https://www.youtube.com/watch?v=lipkLQVqDd8)
