## Enumerated type

[![Перечислимый тип enum в JavaScript и TypeScript](https://img.youtube.com/vi/BXiKebOIAGI/0.jpg)](https://www.youtube.com/watch?v=BXiKebOIAGI)
