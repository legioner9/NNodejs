# Local
Smart local area, township, housing, city solution
