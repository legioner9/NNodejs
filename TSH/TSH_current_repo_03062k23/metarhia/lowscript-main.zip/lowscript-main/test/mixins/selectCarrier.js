async () => {
  const carrier = {
    carrierId: 1,
    carrier: 'Postal service',
  };
  return carrier;
};
