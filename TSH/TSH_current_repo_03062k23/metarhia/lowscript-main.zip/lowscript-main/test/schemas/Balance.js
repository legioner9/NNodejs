({
  amount: 'number',
});
