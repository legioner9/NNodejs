({
  Entity: {},

  order: 'Order',
  amount: 'number',
  transaction: 'string',
  date: { type: 'datetime', default: 'now' },
});
