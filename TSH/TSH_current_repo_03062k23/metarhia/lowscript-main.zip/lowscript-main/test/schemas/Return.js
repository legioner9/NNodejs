({
  Entity: {},

  product: 'Product',
  amount: 'number',
  created: { type: 'datetime', default: 'now' },
});
