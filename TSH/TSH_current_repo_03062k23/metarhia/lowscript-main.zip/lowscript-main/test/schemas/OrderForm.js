({
  product: 'Product',
  carrier: 'Carrier',
  amount: 'number',
});
