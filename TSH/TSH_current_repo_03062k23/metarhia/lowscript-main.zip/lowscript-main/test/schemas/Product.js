({
  Entity: {},

  name: { type: 'string', unique: true },
  description: 'string',
  amount: 'number',
  price: 'number',
  weight: 'number',
});
