({
  name: 'demo',
  description: 'B-OS Process Runtime Demo',
  version: 1,
  driver: 'pg',

  authors: [
    { name: 'Timur Shemsedinov', email: 'timur.shemsedinov@gmail.com' },
  ],
});
