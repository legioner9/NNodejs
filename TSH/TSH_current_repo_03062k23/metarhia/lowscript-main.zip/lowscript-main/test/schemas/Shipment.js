({
  Entity: {},

  package: 'Package',
  carrier: 'Carrier',
  waybill: 'string',
  date: { type: 'datetime', default: 'now' },
});
