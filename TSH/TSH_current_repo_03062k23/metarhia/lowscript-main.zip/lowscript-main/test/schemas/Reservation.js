({
  Entity: {},

  product: 'Product',
  amount: 'number',
  active: 'boolean',
  created: { type: 'datetime', default: 'now' },
});
