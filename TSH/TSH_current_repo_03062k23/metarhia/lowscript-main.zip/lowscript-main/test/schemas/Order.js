({
  Entity: {},

  product: 'Product',
  buyer: 'Account',
  carrier: 'Carrier',
  amount: 'number',
  total: 'number',
  created: { type: 'datetime', default: 'now' },
});
