({
  confirmed: 'boolean',
});
