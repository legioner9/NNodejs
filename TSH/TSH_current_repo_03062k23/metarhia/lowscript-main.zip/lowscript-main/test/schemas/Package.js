({
  Entity: {},

  order: 'Order',
  weight: 'number',
  created: { type: 'datetime', default: 'now' },
});
