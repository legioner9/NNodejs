# Swayer - schema based frontend framework 👀

[![npm version](https://img.shields.io/npm/v/swayer)](https://www.npmjs.com/package/swayer)
[![npm downloads/month](https://img.shields.io/npm/dm/swayer.svg)](https://www.npmjs.com/package/swayer)
[![npm downloads](https://img.shields.io/npm/dt/swayer.svg)](https://www.npmjs.com/package/swayer)
[![snyk](https://snyk.io/test/github/metarhia/swayer/badge.svg)](https://snyk.io/test/github/metarhia/swayer)
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/metarhia/swayer/blob/main/LICENSE)

**UI web framework** for controllable and low overhead development.

## Repository moved to author's profile: https://github.com/rohiievych/swayer
