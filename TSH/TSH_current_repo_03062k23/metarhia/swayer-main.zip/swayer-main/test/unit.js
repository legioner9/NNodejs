['runtime'].map((test) => require('./' + test));
