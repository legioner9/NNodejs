import Head from './pages/head.js';
import Index from './pages/index.js';
import Form from './features/form/form.js';

export default {
  Head,
  Index,
  Form,
};
