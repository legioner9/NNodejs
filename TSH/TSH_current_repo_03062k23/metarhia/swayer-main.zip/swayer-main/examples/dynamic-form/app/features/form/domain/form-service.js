class FormService {
  async sendFormData(action, data) {
    console.log('Call', action, data);
  }
}
export default new FormService();
