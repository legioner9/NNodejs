# Simple dynamic form built with Swayer

## Run locally

```
npm i
npm start
```

## [See online demo](https://metarhia.github.io/swayer/examples/dynamic-form/)
