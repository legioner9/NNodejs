# Todo application built with Swayer

## Run locally

```
npm i
npm start
```

## [See online demo](https://metarhia.github.io/swayer/examples/todo-app/)
