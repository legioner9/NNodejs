'use strict';

const wt = require('worker_threads');
console.log(wt);

require('impress');
