({
  name: 'example',
  description: 'Example database schema',
  version: 4,
  driver: 'pg',

  authors: [
    { name: 'Timur Shemsedinov', email: 'timur.shemsedinov@gmail.com' },
  ],
});
