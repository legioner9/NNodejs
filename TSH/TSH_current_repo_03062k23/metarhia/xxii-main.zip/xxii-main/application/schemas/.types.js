({
  datetime: 'timestamp with time zone',
  json: 'jsonb',
  ip: 'inet',
});
