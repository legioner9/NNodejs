({
  Entity: { x: 1 },

  name: { type: 'string', unique: true, length: 80 },
  country: 'Country',
});
