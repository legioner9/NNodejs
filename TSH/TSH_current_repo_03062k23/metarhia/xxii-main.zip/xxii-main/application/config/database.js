({
  host: '127.0.0.1',
  port: 5432,
  database: 'application',
  user: 'flush1091',
  password: 'DfXP23aqw9038',
});
