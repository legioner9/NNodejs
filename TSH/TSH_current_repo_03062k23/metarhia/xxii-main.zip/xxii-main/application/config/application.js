({
  extends: ['repo1/application'],
});
