({
  size: '50mb',
  maxFileSize: '10mb',
});
