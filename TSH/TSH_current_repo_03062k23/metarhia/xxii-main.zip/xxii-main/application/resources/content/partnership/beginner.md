# Collaboration offer for an individual beginner specialist

You can join community groups, watch open lectures, ask questions, do practical
tasks in HowProgrammingWorks repositories. All listed activities are free but we
have mentorship program, so you can find someone who can do code review for you,
help to contribute for the first time, develop real projects together for certain
hourly rate.

## Links, channels and groups

- [Timur Shemsedinov](https://www.youtube.com/TimurShemsedinov) free video lectures
- [HowProgrammingWorks](https://www.meetup.com/HowProgrammingWorks) meetup group
- [NodeUA](https://www.meetup.com/NodeUA) meetup group
- [KievNodeJS](https://www.meetup.com/KievNodeJS) meetup group (old, not active)
- [HowProgrammingWorks](https://t.me/HowProgrammingWorks) telegram channel
- [HowProgrammingWorks](https://t.me/MetarhiaHPW) telegram group
- [Metarhia](https://t.me/metarhia) telegram channel
- [NodeUA](https://t.me/nodeua) and Metarhia telegram group
