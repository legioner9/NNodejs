INSERT INTO "Country" ("name") VALUES
  ('Soviet Union'),
  ('People''s Republic of China'),
  ('Vietnam'),
  ('Cuba');

INSERT INTO "City" ("name", "countryId") VALUES
  ('Beijing', 2),
  ('Wuhan', 2),
  ('Kiev', 1),
  ('Havana', 4),
  ('Hanoi', 3),
  ('Kaliningrad', 1);
