# Metadomain is Metarhia core database model

[![npm version](https://badge.fury.io/js/metadomain.svg)](https://badge.fury.io/js/metadomain)
[![npm downloads/month](https://img.shields.io/npm/dm/metadomain.svg)](https://www.npmjs.com/package/metadomain)
[![npm downloads](https://img.shields.io/npm/dt/metadomain.svg)](https://www.npmjs.com/package/metadomain)
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/metarhia/metadomain/blob/master/LICENSE)
