({
  Projection: {
    schema: 'Account',
    fields: ['login', 'password', 'email', 'phone'],
  },
});
