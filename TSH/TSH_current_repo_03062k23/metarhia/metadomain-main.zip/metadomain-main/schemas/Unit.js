({
  Registry: {},

  name: { type: 'string', unique: true },
  parent: '?Unit',
});
