({
  Entity: {},

  name: { type: 'string', unique: true },
  data: 'json',
});
