# Changelog

## [Unreleased][unreleased]

- Prevent arbitrary js code execution
- Implement unknown identifier hook

## [0.0.1][] - 2022-05-13

- First simple implementation
- Implement Math namespace

## [0.0.0][] - 2022-05-12

- Library stucture

[unreleased]: https://github.com/metarhia/metacalc/compare/v0.0.1...HEAD
[0.0.1]: https://github.com/metarhia/metacalc/compare/v0.0.0...v0.0.1
[0.0.0]: https://github.com/metarhia/metacalc/releases/tag/v0.0.0
