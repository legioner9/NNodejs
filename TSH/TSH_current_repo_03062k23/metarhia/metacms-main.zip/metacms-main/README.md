# MetaCMS

[![ci status](https://github.com/metarhia/metacms/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/metacms/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![snyk](https://snyk.io/test/github/metarhia/metacms/badge.svg)](https://snyk.io/test/github/metarhia/metacms)
[![npm version](https://badge.fury.io/js/metacms.svg)](https://badge.fury.io/js/metacms)
[![npm downloads/month](https://img.shields.io/npm/dm/metacms.svg)](https://www.npmjs.com/package/metacms)
[![npm downloads](https://img.shields.io/npm/dt/metacms.svg)](https://www.npmjs.com/package/metacms)
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/metarhia/metacms/blob/master/LICENSE)

## License & Contributors

Copyright (c) 2022 [Metarhia contributors](https://github.com/metarhia/metacms/graphs/contributors).
MetaCMS is [MIT licensed](./LICENSE).\
MetaCMS is a part of [Metarhia](https://github.com/metarhia) technology stack.
