# Changelog

## [Unreleased][unreleased]

## [0.0.0][] - 2022-07-10

- Library stucture

[unreleased]: https://github.com/metarhia/metacms/compare/v0.0.0...HEAD
[0.0.0]: https://github.com/metarhia/metacms/releases/tag/v0.0.0
