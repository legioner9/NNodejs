'use strict';

/* This is a stub */
