'use strict';

const method3 = async (value) => {
  if (value) return { key: value };
  return null;
};

const method4 = async (value) => {
  if (value) return { key: value };
  return null;
};

module.exports = { method3, method4 };
