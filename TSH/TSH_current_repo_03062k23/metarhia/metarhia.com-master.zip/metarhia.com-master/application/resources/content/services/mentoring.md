# Metaeducation and Metarhia mentoring programm

Common Groups:
[💬 Global Channel]{metaedu}
[💬 Global Chat]{joinchat/znsE73dPWLQ5Nzky}
[💬 Newbies]{joinchat/_P6ynQcT6gQ4OGUy}
[💬 Mentors]{joinchat/eLrAEPzZvC81NWUy}

Cities:
[🏙️ Kiev]{joinchat/qAKpm5byRqQxNWZi}
[🏙️ Kiev Kids]{joinchat/Vnv-Ot_J4jw3MDVi}
[🏙️ Moscow]{joinchat/BQY_GMG9Jes5NTBi}
[🏙️ Minsk]{joinchat/rd7QqJz4iIBmM2Yy}
[🏙️ Odessa]{joinchat/3yVc-kWsYENhMzUy}
[🏙️ Kharkov]{joinchat/JGXPU_GZUYoyNDE6}
[🏙️ Lviv]{joinchat/08PKA8pWIPU0MDgy}
[🏙️ Piter]{joinchat/rf2UXW2eFrMyOWMy}

Metarhia subsystems:
[🌍 Internationalization]{joinchat/zZNKn2PcBYBhZGE6}
[🔐 AAA Subsystem]{joinchat/hVAozLWVq581MGMy}
[📯 Metanet]{joinchat/wUrZxv0WexM0ODA6}
[🤖 Chats and Bots]{joinchat/O-k-g7r4p-Y2NmYy}
[📁 Metanet Files]{joinchat/1Gyj_DYrIlNkYjEy}
[✉️ Metanet Mail]{joinchat/YYPK6Wm8ompjMmIy}
[👁️ Monitoring]{joinchat/4YXl7mZ72WJiNTNi}
[🪙 Payment Integration]{joinchat/C0eTgGv7KwNhODFi}
[🧪 Metatests]{joinchat/2RLxBESTlRRhZjUy}
[🐘 Metasql]{joinchat/pQX8DPQbEHw0NTIy}
[💡 Metaschema]{joinchat/PnnnBfuKBkc0YTdi}
[🔌 Metacom]{joinchat/y8YHMD-_OS5mMGQy}
[⚡ Impress]{joinchat/P9N-CU0RggM2MjFi}
[🧰 Metautil]{joinchat/zxzGipd6shlkZGZi}
[🌍 Globalstorage]{joinchat/2FjXFo6aERc1MjIy}

Metahealth project:
[💻 Backend API]{joinchat/m_yFHN77k_AzNzIy}
[💻 Domain model]{joinchat/GBAUTtsEfGY0Y2Iy}
[💻 System integration]{joinchat/2cfYvtP0CXtjOWJi}
[💻 Business Analysis]{joinchat/9FUSFALKGy82ZjQy}
[💻 Architecture]{joinchat/m1NJFqXcf6UyZGJi}
[💻 Metagui]{joinchat/EuVH5sPPoAUzYjYy}
[💻 Frontend core]{joinchat/sfOBW43R0VZlOGQ6}
[💻 Web Components]{joinchat/35hj2EgvxlE1YjIy}
[💻 React Components]{joinchat/M32OghhNU2U5MzIy}
[💻 Vue Components]{joinchat/jyTSrKj4Yts3MzYy}
[💻 Angular Components]{joinchat/tpJmEGKZ0-gxOGMy}

Other technology stacks:
[🚀 Java]{joinchat/wHGaWUIpEvY5MTQy}
[🚀 .NET and C Sharp]{joinchat/xnAxvTRsSHJiOWNi}

Back to [home](home.md) page.
