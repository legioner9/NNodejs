# Metarhia stack roadmap

- 2021 January: Add metaschema, metawatch and metautil to the stack
- 2021 February: Implement file transfer and context protection
- 2021 March: Improve metasql, migrations and query builder
- 2021 April: Monitoring, health and firewall functionality
- 2021 May: Add testing, deploy and CI/CD tools
