# Metarhia key technology features

- Enterprise-level application server
- Designed for secure private cloud application
- First node.js server scaling via threads
- For real-time interactive long-lived connections
- Security, context isolation and sandboxing for security
- No third-party dependencies, no vendor lock
- Optimized TTM, focus on business/product
- Integral application architecture (not just cloud functions)
- Education programs and certification
