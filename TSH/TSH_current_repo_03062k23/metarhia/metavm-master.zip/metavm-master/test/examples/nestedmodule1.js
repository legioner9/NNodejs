module.exports = {
  name: 'nestedmodule1',
  value: 1,
  nested: require('./nestedmodule2.js'),
};
