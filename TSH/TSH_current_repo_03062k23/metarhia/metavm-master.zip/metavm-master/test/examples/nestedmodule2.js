module.exports = {
  name: 'nestedmodule2',
  value: 2,
};
