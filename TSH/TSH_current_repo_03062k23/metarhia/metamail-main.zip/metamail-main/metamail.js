'use strict';

module.exports = {
  ...require('./lib/smtp/smtp-transport.js'),
};
