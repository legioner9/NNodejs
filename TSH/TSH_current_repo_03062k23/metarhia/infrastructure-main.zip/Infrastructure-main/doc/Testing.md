## Testing module

There is a great functionality of [Artillery](https://artillery.io/) and [CLinic.js](https://clinicjs.org/), including ws testing scenarions and analisys of system bottlneks. We can integrate them for initial testing system, having in mind further developmant of in house analogs.