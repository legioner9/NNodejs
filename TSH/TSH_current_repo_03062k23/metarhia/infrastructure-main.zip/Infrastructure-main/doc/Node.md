## Node Module

Separate multipurpose customized node with self checking functionality. A basic cell of Metarhia claster. Distributed in docker container with predefined configuration and manageable from command center.

Upon activation receives credentials from command center, connects to particular levels of data storages, and sibling nodes in a claster. Should test and report particular  machine characteristics, and launch several processes, according to CPU power, RAM availability and designated purpose in the cluster.

