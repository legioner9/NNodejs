## Dependencies module

1. CDN
2. EMail
3. Payment
