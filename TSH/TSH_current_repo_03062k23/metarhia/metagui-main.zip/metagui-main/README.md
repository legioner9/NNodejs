# Meta GUI

GUI Components for Metarhia technology stack.

## License & Contributors

Copyright (c) 2021 [Metarhia contributors](https://github.com/metarhia/metagui/graphs/contributors).
MetaGUI is [MIT licensed](./LICENSE).\
MetaGUI is a part of [Metarhia](https://github.com/metarhia) technology stack.
