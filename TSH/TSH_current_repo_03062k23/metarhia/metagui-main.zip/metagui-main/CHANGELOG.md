# Changelog

## [Unreleased][unreleased]

## [0.0.0][] - 2020-09-22

[unreleased]: https://github.com/metarhia/metagui/compare/v0.0.0....HEAD
[0.0.0]: https://github.com/metarhia/metagui/releases/tag/v0.0.0
