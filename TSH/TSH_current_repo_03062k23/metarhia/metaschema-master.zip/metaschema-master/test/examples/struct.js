({
  field1: 'string',
  field2: 'number',
});
