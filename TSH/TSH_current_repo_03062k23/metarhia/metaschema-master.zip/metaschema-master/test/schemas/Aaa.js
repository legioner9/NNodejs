({
  Projection: {
    schema: 'Account',
    fields: ['login', 'password'],
  },
});
