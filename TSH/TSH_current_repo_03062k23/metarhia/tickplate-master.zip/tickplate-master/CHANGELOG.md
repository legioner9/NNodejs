# Changelog

## [Unreleased][unreleased]

## [1.0.6][] - 2023-02-20

- Package maintenance

## [1.0.5][] - 2022-07-07

- Package maintenance

## [1.0.4][] - 2022-05-12

- Package maintenance

## [1.0.3][] - 2021-07-17

- Fix d.ts typings and include typings to package publishing files
- Chore: update package files, copyrights, links

## [1.0.2][] - 2021-07-15

- Add d.ts typings
- Package maintenance

## [1.0.1][] - 2021-06-14

- Refresh package (dependencies, ci, badges, code style)

## [1.0.0][] - 2020-12-16

- Reflect data structures to template with tick syntax

## [0.0.x][] Pre-release versions

[unreleased]: https://github.com/metarhia/tickplate/compare/v1.0.6...HEAD
[1.0.6]: https://github.com/metarhia/tickplate/compare/v1.0.5...v1.0.6
[1.0.5]: https://github.com/metarhia/tickplate/compare/v1.0.4...v1.0.5
[1.0.4]: https://github.com/metarhia/tickplate/compare/v1.0.3...v1.0.4
[1.0.3]: https://github.com/metarhia/tickplate/compare/v1.0.2...v1.0.3
[1.0.2]: https://github.com/metarhia/tickplate/compare/v1.0.1...v1.0.2
[1.0.1]: https://github.com/metarhia/tickplate/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/metarhia/tickplate/compare/v0.0.x...v1.0.0
[0.0.x]: https://github.com/metarhia/tickplate/releases/tag/v0.0.x
