declare function tickplate(strings: Array<string>, ...keys: Array<string>): (values: object) => string;

export = tickplate;
