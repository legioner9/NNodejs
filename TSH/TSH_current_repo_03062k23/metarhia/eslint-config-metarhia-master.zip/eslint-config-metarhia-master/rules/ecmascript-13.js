'use strict';

module.exports = {
  rules: {
    'no-unused-private-class-members': ['error'],
    'no-invalid-this': ['error'],
    'class-methods-use-this': ['warn'],
  },
};
