'use strict';

module.exports = {
  parserOptions: {
    ecmaVersion: 'latest',
  },
};
