# Mtypes: Metarhia common types

[![ci status](https://github.com/metarhia/mtypes/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/mtypes/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![snyk](https://snyk.io/test/github/metarhia/mtypes/badge.svg)](https://snyk.io/test/github/metarhia/mtypes)
[![npm version](https://badge.fury.io/js/mtypes.svg)](https://badge.fury.io/js/mtypes)
[![npm downloads/month](https://img.shields.io/npm/dm/mtypes.svg)](https://www.npmjs.com/package/mtypes)
[![npm downloads](https://img.shields.io/npm/dt/mtypes.svg)](https://www.npmjs.com/package/mtypes)
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/metarhia/mtypes/blob/master/LICENSE)

## License & Contributors

Copyright (c) 2022 [Metarhia contributors](https://github.com/metarhia/mtypes/graphs/contributors).
Mtypes is [MIT licensed](./LICENSE).\
Mtypes is a part of [Metarhia](https://github.com/metarhia) technology stack.
