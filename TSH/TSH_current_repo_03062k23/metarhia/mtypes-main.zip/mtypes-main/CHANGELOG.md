# Changelog

## [Unreleased][unreleased]

## [0.0.0][] - 2022-05-12

- Library stucture

[unreleased]: https://github.com/metarhia/mtypes/compare/v0.0.0...HEAD
[0.0.0]: https://github.com/metarhia/mtypes/releases/tag/v0.0.0
