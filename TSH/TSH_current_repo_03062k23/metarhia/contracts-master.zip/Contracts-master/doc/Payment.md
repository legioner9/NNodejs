# Payment subsystem

Multi purpose configurable system that includes industry standard components for
transaction performance, verification, storage, monitoring, and analytics. API
connections to payment gateways.
