'use strict';

console.log('No integration tests implemented');
