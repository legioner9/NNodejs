'use strict';

console.log('No server tests implemented');
