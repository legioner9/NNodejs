({
  cloud: 'PrivateWebsite',
  server: '1',
  instance: 'standalone',
  token: 'Da20-2E40N9^f5g63Tj97w6r2T3_yL0w',
  gc: 60 * 60 * 1000,
});
