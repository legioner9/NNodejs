window.addEventListener('load', async () => {
  console.log('Hello world!');
});
