() => {
  console.debug('Call method: example.submodule2.method2');
};
