async () => {
  console.debug('Stop example plugin');
};
