({
  keepDays: 'number',
  writeInterval: 'number',
  writeBuffer: 'number',
  toFile: { array: 'string' },
  toStdout: { array: 'string' },
  json: '?boolean',
});
