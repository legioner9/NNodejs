({
  internal: ['fs', 'path', 'http'],
  external: ['metautil', 'metasync', 'eslint'],
});
