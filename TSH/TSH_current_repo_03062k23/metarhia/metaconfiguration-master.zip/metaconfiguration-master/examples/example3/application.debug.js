({
  name: 'Application name: Debug mode',
});
