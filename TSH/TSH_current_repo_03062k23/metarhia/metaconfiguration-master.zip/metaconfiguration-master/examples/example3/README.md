# Example 3

This files should be omitted
