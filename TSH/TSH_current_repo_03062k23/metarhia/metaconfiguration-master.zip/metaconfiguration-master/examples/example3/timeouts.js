({
  cache: 30 * 1000,
  relpy: 5 * 1000,
  query: 3 * 1000,
});
