({
  transport: 'http',
  address: '127.0.0.1',
  ports: 8080,
});
