({
  internal: ['fs', 'path', 'http'],
  external: ['metautil'],
});
