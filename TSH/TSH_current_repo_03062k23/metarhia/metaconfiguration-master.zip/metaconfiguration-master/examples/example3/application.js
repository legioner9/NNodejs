({
  name: 'Application name',
});
