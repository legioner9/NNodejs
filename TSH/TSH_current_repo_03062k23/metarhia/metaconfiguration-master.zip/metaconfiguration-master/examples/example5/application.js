({
  name: 'Application name',
  user: process.env.USER,
});
