({
  interval: 30000,
  active: true,
});
