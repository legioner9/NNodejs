async () => {
  throw new Error('Example exception');
};
