async () => {
  throw new Error('Custom ecxeption', 12345);
};
