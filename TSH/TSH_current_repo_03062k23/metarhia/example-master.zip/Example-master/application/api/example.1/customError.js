async () => new Error('Return custom error', 12345);
