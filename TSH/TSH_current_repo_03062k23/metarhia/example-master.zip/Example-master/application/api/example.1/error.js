async () => new Error('Return error');
