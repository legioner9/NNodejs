({
  method: {
    get: 'timezone',
  },

  returns: { array: 'string' },
});
