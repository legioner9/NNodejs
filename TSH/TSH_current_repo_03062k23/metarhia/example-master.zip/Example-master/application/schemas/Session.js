({
  Entity: {},

  account: 'Account',
  token: { type: 'string', unique: true },
  ip: 'ip',
  data: 'json',
});
