({
  Entity: {},

  name: { type: 'string', unique: true },
  country: 'Country',
});
