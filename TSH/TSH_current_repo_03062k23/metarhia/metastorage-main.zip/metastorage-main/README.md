# Metastorage

[![ci status](https://github.com/metarhia/metastorage/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/metastorage/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![snyk](https://snyk.io/test/github/metarhia/metastorage/badge.svg)](https://snyk.io/test/github/metarhia/metastorage)
[![npm version](https://badge.fury.io/js/metastorage.svg)](https://badge.fury.io/js/metastorage)
[![npm downloads/month](https://img.shields.io/npm/dm/metastorage.svg)](https://www.npmjs.com/package/metastorage)
[![npm downloads](https://img.shields.io/npm/dt/metastorage.svg)](https://www.npmjs.com/package/metastorage)
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/metarhia/metastorage/blob/master/LICENSE)

## License & Contributors

Copyright (c) 2022 [Metarhia contributors](https://github.com/metarhia/metastorage/graphs/contributors).
Metastorage is [MIT licensed](./LICENSE).\
Metastorage is a part of [Metarhia](https://github.com/metarhia) technology stack.
