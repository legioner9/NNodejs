# Metarhia technology stack

- [Quick start](START.md)
- [Application structure](APPLICATION.md)
- [External interfaces documentation](DOCS.md)
- [Technology internals](INTERNALS.md)
