# Technology internals
