# External interfaces documentation
